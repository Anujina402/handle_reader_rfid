package com.pda.uhf_g.application;

import android.app.Application;



public class UhfApplication extends Application {

    String TAG = "UhfApplication";
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
